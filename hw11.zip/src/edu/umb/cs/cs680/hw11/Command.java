package edu.umb.cs.cs680.hw11;

public interface Command {
	 void execute();

}
